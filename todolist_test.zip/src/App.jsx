import Todolist from "./components/layout/Todolist";

function App() {
  return (
    <div className="App">
      <Todolist />
    </div>
  );
}

export default App;
